var express = require("express");
const jwt = require("jsonwebtoken");
var router = express.Router();
const connection = require("./../database/connection");

/* GET users listing. */
router.post("/user-list", function (req, res, next) {
  try {
    let page_no = "";

    if (isNaN(parseInt(req.body.page_no))) {
      page_no = 1;
    } else if (req.body.page_no <= 0) {
      page_no = 1;
    } else {
      page_no = parseInt(req.body.page_no);
    }

    const limit = 10;
    const offset = page_no * 10 - 10;

    // Retrieve user from the database
    const selectQuery = `
    SELECT
      id,
      name,
      email,
      phone,
      user_type,
      CASE
        WHEN image IS NULL THEN NULL
        ELSE CONCAT('${process.env.ASSETS_URL_BASE}uploads/users/', image)
      END AS image
    FROM
      users
    WHERE
      user_type = 2
    LIMIT ${limit}
    OFFSET ${offset}`;

    connection.query(selectQuery, async (error, results, fields) => {
      if (error) {
        console.log(error);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.length > 0) {
        res
          .status(200)
          .json({ message: "User list successfully displayed", data: results });
      } else {
        return res.status(400).json({ error: "Data not found" });
      }
    });
  } catch (err) {
    res.status(500).json({ message: "Internal Server Error" });
  }
});

// Update user
router.put("/update-user", function (req, res, next) {
  try {
    // Validate required fields
    const requiredFields = ["userId", "name", "phone", "email"];
    for (const field of requiredFields) {
      if (!req.body[field]) {
        return res
          .status(400)
          .json({ message: `Missing required field: ${field}` });
      }
    }

    let userId = 0;
    //Checking for the valid user id
    if (isNaN(parseInt(req.body.userId))) {
      userId = 0;
    } else {
      userId = req.body.userId;
    }

    // Make an update query
    const updateQuery =
      "UPDATE users SET name = ?, phone = ?, email = ? WHERE user_id = ?";

    connection.query(
      updateQuery,
      [req.body.name, req.body.phone, req.body.email, userId],
      (error, results, fields) => {
        if (error) {
          return res.status(500).json({ error: "Internal Server Error" });
        }

        if (results.length > 0) {
          return res.status(200).json({ message: `User updated successfully` });
        }
      }
    );
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
